package com.ibs.connected.room.log;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Transformer {

	private Map<String, String> wordMap;

	public Transformer() throws FileNotFoundException {
		//Get file from resources folder
		ClassLoader classLoader = getClass().getClassLoader();
		//File file = new File(classLoader.getResource("dictionary.txt").getFile());
		File file = new File("src/main/resources/dictionary.txt");
		try (Scanner scanner = new Scanner(file);){
			wordMap = new HashMap<>();
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				//System.out.println(line);
				String[] parts = line.split("===");
				String word = parts[0];
				String shortWord = parts[1];
				wordMap.put(word, shortWord);
			}
		}
	}


	private String shortenWord( String inWord ) {
		String punc;
		String currentWord = inWord.toLowerCase();
		if (currentWord.endsWith("?")) {
			currentWord = currentWord.replaceAll("\\?","");
			punc = "?";
		}else if (currentWord.endsWith(",")) {
			currentWord = currentWord.replaceAll("\\,","");
			punc = ",";
		}else if (currentWord.endsWith(".")) {
			currentWord = currentWord.replaceAll("\\.","");
			punc = ".";
		}else if (currentWord.endsWith("!")) {
			currentWord = currentWord.replaceAll("\\!","");
			punc = "!";
		}else if (currentWord.endsWith(";")) {
			currentWord = currentWord.replaceAll("\\;","");
			punc = ";";
		}else if (currentWord.endsWith(":")) {
			currentWord = currentWord.replaceAll("\\:","");
			punc = ":";
		}
	  else {
			punc = "";
		}

		if (wordMap.containsKey(currentWord)){
			String shortenedWord = wordMap.get(currentWord);
			shortenedWord = shortenedWord + punc;
			return shortenedWord;
		}

		currentWord += punc;
		return currentWord;  
	}


	public String transformMessage( String inMessage ) {
		
		String temporaryLine = temporaryConversion(inMessage);
		
		StringBuilder message = new StringBuilder();
		//String[] splitArray = inMessage.split("\\s+|?=\\*?=\\*?=\\[|?=\\]|?=\\=|?=\\:|?=\\,|?=\\(|?=\\)|?=\\[");
		//String[] splitArray = inMessage.split("\\s+|\\=+|\\:+|\\(+|\\)+|\\,+");
		String[] splitArray = temporaryLine.split("\\s+");
		for (String eachWord: splitArray ){
			message.append(shortenWord(eachWord)).append(" ");
		}
		String returnedLine = message.toString();

		String replacd = returnedLine.replaceAll(" \\|\\| ", "");
		replacd = replacd.replaceAll("\\|\\| ", "");
		replacd = replacd.replaceAll(" \\|\\|", "");
		
		return replacd.trim();
	}
	
	private String temporaryConversion(String line) {
		Matcher matcher = Pattern.compile("(,|:|]|\\[|=|\\(|\\)|\\{)").matcher(line);

		int count = 0;
		StringBuffer sb = new StringBuffer();
		while (matcher.find()) {
			count++;

			/*System.out.println("found: " + count + " : "

					+ matcher.start() + " - " + matcher.end());*/
			String matched = matcher.group();
			//System.out.println("matched: " + matched);
			int end = matcher.end();

			if (end < line.length()) {
				//System.out.println("end: " + line.charAt(end));
				char next = line.charAt(end);
				if (next == ' ') {
					matcher.appendReplacement(sb, " || $1 ");
				} else {
					matcher.appendReplacement(sb, " || $1 || ");
				}
			} else {
				matcher.appendReplacement(sb, " || $1 ");
			}

		}

		matcher.appendTail(sb);

		String result = sb.toString();
		//System.out.println("changed "+result);
		return result;
	}
}