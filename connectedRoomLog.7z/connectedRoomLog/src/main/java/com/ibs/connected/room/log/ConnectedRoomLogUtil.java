package com.ibs.connected.room.log;

import java.io.IOException;

import org.apache.commons.configuration.ConfigurationException;

public class ConnectedRoomLogUtil {

	public static void main(String[] args) {
		ConnectedRoomLogProcessor crLogProcessoror = new ConnectedRoomLogProcessor();
		try {
			crLogProcessoror.extract();
			crLogProcessoror.transform();
		} catch (ConfigurationException | IOException e) {
			e.printStackTrace();
		}
		

	}

}
