package com.ibs.connected.room.log;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Properties;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;

public class ConnectedRoomLogProcessor {
	File extractedFile = null;
	/*public static void main(String[] args) throws IOException, ConfigurationException {
      ConnectedRoomLogProcessor parseCRLogs = new ConnectedRoomLogProcessor();
      parseCRLogs.extract();
      parseCRLogs.transform();
    }*/

	public void extract() throws IOException, ConfigurationException{

		String eventLogDirectory = "src/main/resources/logs";
		File dir = new File(eventLogDirectory);
		File[] eventLogFiles = dir.listFiles();

		File extractedFile = new File("src/main/resources/output/EX/ExtractedOut.txt");
		if (!extractedFile.exists()) {
			extractedFile.createNewFile();
		} 
		FileWriter filewriter = new FileWriter(extractedFile.getAbsoluteFile());
		BufferedWriter logExtractedOutWriterStream= new BufferedWriter(filewriter);    
		System.out.println("Extracting...");
		for (File eventLogFile : eventLogFiles) {
			
			if(eventLogFile.isFile()) {
				BufferedReader actualEventLogReaderStream = null;          
				try {
					actualEventLogReaderStream = new BufferedReader(
							new FileReader(eventLogFile));
					String line;                    
					PropertiesConfiguration config = new PropertiesConfiguration("src/main/resources/config.properties");
					String[] filterKeys = config.getStringArray("filterkeys");
					String[] excludeKeys = config.getStringArray("exclude");
					while ((line = actualEventLogReaderStream.readLine()) != null) {
						try {
							line = line.replace(line.substring(19, 30), "");	
						} catch (StringIndexOutOfBoundsException e) {
						  System.out.println(line);
						}
						
						for(String filterKey : filterKeys){
							if(line.contains(filterKey)){
								boolean excludeLine = false;
								for(String exclude : excludeKeys){
									if(line.contains(exclude)){
										excludeLine = true;
										break;
									}
								}
								if (!excludeLine) {
									logExtractedOutWriterStream.write(line+"\n");
								}
							}
						}                  
					}                 
				}
				finally {
					if (actualEventLogReaderStream != null) {
						actualEventLogReaderStream.close();
					}

				}
			}
		}
		if (logExtractedOutWriterStream != null) {
			logExtractedOutWriterStream.close();
		}
		System.out.println("\n\nExtraction finished.");
	}

	public void transform() throws IOException{
		File transformedFile = new File("src/main/resources/output/TransformedOut.txt");
		BufferedReader logExtractedOutReaderStream = null;
		FileWriter logTransformFileWriter = new FileWriter(transformedFile.getAbsoluteFile());
		BufferedWriter LogtransformdOutWriterStream= new BufferedWriter(logTransformFileWriter);

		if (!transformedFile.exists()) {
			transformedFile.createNewFile();
		}
		System.out.println("\n\nTransforming...");
		Transformer transformer = new Transformer();    
		try{                 
			String linetoTransform;  
			logExtractedOutReaderStream = new BufferedReader(
					new FileReader("src/main/resources/output/ExtractedOut.txt"));
			while ((linetoTransform = logExtractedOutReaderStream.readLine()) != null) {

				//System.out.println("LineToTransform: "+linetoTransform);
				String shortenedMessage = transformer.transformMessage(linetoTransform);  
				// System.out.println("transformed: "+shortenedMessage);
				LogtransformdOutWriterStream.write(shortenedMessage+"\n");
			}

		}finally {
			if (logExtractedOutReaderStream != null) {
				logExtractedOutReaderStream.close();
			}
			if (LogtransformdOutWriterStream != null) {
				LogtransformdOutWriterStream.close();
			}
		}
		System.out.println("\n\nTransformation finished.");
	}

}