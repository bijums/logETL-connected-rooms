package com.ibs.connected.room.log;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Test {

	public static void main(String[] args) throws FileNotFoundException {
		
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(
					"src/main/resources/logs_bk/athena logs/tstat_details_for athena.txt"));
			String line = reader.readLine();
			while (line != null) {
				
				// read next line
				line = reader.readLine();
				//System.out.println(line.substring(0, 5));
				System.out.println(line.substring(25, line.length()));
				//System.out.println(line.substring(18, 29));
				//System.out.println(line.substring(31, 36));
				//System.out.println(line.substring(38, 42));
				//System.out.println(line.substring(43, line.length()));
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}
		/*String test = ",one,:two:three]";

		Matcher matcher = Pattern.compile("(,|:|])").matcher(test);

		int count = 0;

		StringBuffer sb = new StringBuffer();

		while (matcher.find()) {

			count++;

			System.out.println("found: " + count + " : "

					+ matcher.start() + " - " + matcher.end());

			String matched = matcher.group();

			System.out.println("matched: " + matched);

			int end = matcher.end();

			if (end < test.length()) {

				System.out.println("end: " + test.charAt(end));

				char next = test.charAt(end);

				if (next == ' ') {

					matcher.appendReplacement(sb, " || $1 ");

				} else {

					matcher.appendReplacement(sb, " || $1 || ");

				}

			} else {

				matcher.appendReplacement(sb, " || $1 ");

			}

		}

		matcher.appendTail(sb);

		System.out.println("*****" + sb.toString());

		Transformer former = new Transformer();

		String changed = former.transformMessage(sb.toString());

		System.out.println("changed: ->" + changed);

		String replacd = changed.replaceAll(" \\|\\| ", "");

		replacd = replacd.replaceAll("\\|\\| ", "");

		replacd = replacd.replaceAll(" \\|\\|", "");

		System.out.println("replaced: ->" + replacd + "<-");
	}*/

}
